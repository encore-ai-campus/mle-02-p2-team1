#!/usr/bin/env python3
"""M5 한쪽 미결 제품·행사·지표의 실습용 잠정 정규화. 원본과 DB를 변경하지 않음."""
import argparse
import hashlib
import json
import re
import unicodedata
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

UNRESOLVED = '미결_원문검토필요'
COMPANIES = ['아모레퍼시픽','이니스프리','에스쁘아','에뛰드','퍼시픽테크','아모스프로페셔널','코스알엑스']


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def key(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC',value or '')).casefold()


def make_id(prefix, data):
    return prefix+hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:20]


def brand_key(name):
    # 국문·영문 병기와 자주 사용된 영문 표기는 같은 브랜드 후보로 취급한다.
    # 회사 개체와 브랜드 개체를 합치는 처리는 하지 않는다.
    raw=unicodedata.normalize('NFKC',name or '')
    base=re.sub(r'\([^)]*\)', '', raw).strip() or raw
    normalized=key(base)
    aliases={'cosrx':'코스알엑스','코스알엑스':'코스알엑스','aestura':'에스트라',
             '에스트라':'에스트라','apbeauty':'에이피뷰티','에이피뷰티':'에이피뷰티',
             'innisfree':'이니스프리','이니스프리':'이니스프리',
             'espoir':'에스쁘아','에스쁘아':'에스쁘아','etude':'에뛰드','에뛰드':'에뛰드'}
    return aliases.get(normalized,normalized)


def rows(z,name):
    matches=[x for x in z.namelist() if not x.endswith('/') and Path(x).name==name]
    if len(matches)!=1:raise ValueError(f'{name}: {len(matches)}개 발견; 정확히 1개 필요')
    with z.open(matches[0]) as f:return [json.loads(line) for line in f if line.strip()]


def read_summary(z):
    matches=[x for x in z.namelist() if Path(x).name=='summary.json']
    if len(matches)!=1:raise ValueError('summary.json이 없거나 중복됨')
    return json.loads(z.read(matches[0]))


def save(path,values):
    with path.open('w',encoding='utf-8',newline='\n') as f:
        for v in values:f.write(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--m5',type=Path,required=True,help='기존 m5_output.zip')
    p.add_argument('--m4',type=Path,required=True,help='기존 M4 뉴스 추출 ZIP')
    p.add_argument('--person',type=Path,required=True,help='인물 잠정 정규화 결과 ZIP')
    p.add_argument('--output',type=Path,required=True,help='비어 있는 새 결과 폴더')
    a=p.parse_args()
    if a.output.exists() and (not a.output.is_dir() or any(a.output.iterdir())):
        p.error('기존 결과를 덮어쓰지 않도록 비어 있는 새 폴더가 필요합니다.')
    with zipfile.ZipFile(a.m5) as z:
        m5_summary=read_summary(z)
        relations=rows(z,'news_relations.jsonl')
        mapping=rows(z,'mention_mapping.jsonl')
        old_nodes=rows(z,'canonical_nodes.jsonl')+rows(z,'news_nodes.jsonl')
        structured=rows(z,'structured_disclosure_relations.jsonl')
        disc_docs=rows(z,'disclosure_documents.jsonl')
        disc_chunks=rows(z,'disclosure_chunks.jsonl')
    with zipfile.ZipFile(a.person) as z:
        person_summary=read_summary(z)
        person_nodes=rows(z,'person_nodes_provisional.jsonl')
        prior_relations=rows(z,'news_relations_in_scope.jsonl')
        person_mappings=rows(z,'person_mention_mappings.jsonl')
        previous_person_mappings=rows(z,'previous_person_mappings.jsonl')
        prior_excluded=rows(z,'excluded_both_unresolved.jsonl')
    h5,h4=sha(a.m5),sha(a.m4)
    if person_summary.get('input_sha256',{}).get('m5')!=h5 or person_summary.get('input_sha256',{}).get('m4')!=h4:
        raise ValueError('인물 처리에 사용한 M4·M5 입력과 현재 파일이 다릅니다.')
    if m5_summary.get('inputs',{}).get('m4_sha256')!=h4:
        raise ValueError('M5에 기록된 M4 해시가 현재 파일과 다릅니다.')
    with zipfile.ZipFile(a.m4) as z:
        chunks={x['input']['chunk_id']:x['input'] for x in rows(z,'extractions.jsonl')}
    old_by_id={n['entity_id']:n for n in old_nodes}
    person_by_id={n['entity_id']:n for n in person_nodes}
    if len(old_by_id)!=len(old_nodes) or len(person_by_id)!=len(person_nodes):raise ValueError('개체 ID 중복')
    original={r['relation_id']:r for r in relations}
    if len(original)!=len(relations):raise ValueError('원본 관계 ID 중복')
    prior_ids={r['relation_id'] for r in prior_relations}
    frozen_both={x['relation_id'] for x in prior_excluded}
    if prior_ids & frozen_both:raise ValueError('기존 인물 결과에 양쪽 미결 제외 관계가 포함됨')

    # 처리 전의 범위를 사용한다. 나중에 상태가 바뀌어도 제외 항목을 되살리지 않는다.
    selected=[];other=[];both=set();already=set()
    for r in relations:
        s=r['subject_resolution']==UNRESOLVED;o=r['object_resolution']==UNRESOLVED
        if s and o:both.add(r['relation_id']);continue
        if not s and not o:already.add(r['relation_id']);continue
        side='subject' if s else 'object';nid=r[side+'_id']
        node=old_by_id.get(nid)
        if not node:raise ValueError(f'개체 누락: {nid}')
        if node['type'] in ('Product','Event','MetricObservation'):
            selected.append((r,side,nid,node))
        elif node['type']!='Person':other.append(r)
    if both!=frozen_both:raise ValueError('양쪽 미결 제외 목록이 기존 인물 결과와 다릅니다.')
    if len(selected)+len(other)+len(both)+len(prior_ids)!=len(relations):
        raise ValueError('이전 단계와 이번 단계의 관계 범위가 완전히 분리되지 않습니다.')

    # 하나의 미결 개체 언급에 연결된 관계를 모아 브랜드·행사 시점을 확인한다.
    per_id=defaultdict(list)
    for r,side,nid,node in selected:per_id[nid].append((r,side))
    new_nodes={};resolution={};map_rows=[];groups={};shared_metric=set()
    for nid,items in per_id.items():
        node=old_by_id[nid];typ=node['type'];name=node['name'];src=node.get('source_mention',{})
        chunk_id=src.get('chunk_id'); chunk=chunks.get(chunk_id)
        if not chunk:raise ValueError(f'원문 청크 누락: {nid}')
        text=chunk.get('primary_text',''); literal=bool(key(name)) and key(name) in key(text)
        context=any(c in text for c in COMPANIES)
        old_attrs=node.get('attributes',{})
        if typ=='MetricObservation':
            # 지표는 같은 이름만으로 다른 수치와 병합하지 않는다.
            gid=make_id('OBS-RULE-',nid);mode='지표_개별관측_잠정';group=(typ,nid)
            flags=[]
            if old_attrs.get('value_number') is None:flags.append('수치_없음')
            if not old_attrs.get('unit'):flags.append('단위_없음')
            subjects={r['subject_id'] for r,_ in items}
            if len(subjects)>1:flags.append('여러대상_공유관측_검토');shared_metric.add(nid)
        elif typ=='Product':
            brands=set()
            for r,side in items:
                if r['predicate']=='PRODUCT_UNDER_BRAND' and side=='subject':
                    target=old_by_id[r['object_id']]
                    if target['type']=='Brand':brands.add(brand_key(target['name']))
            if literal and context and len(brands)<=1:
                # 제품명+브랜드 기준. 브랜드 미상은 미상끼리만 그룹화한다.
                group=(typ,key(name),next(iter(brands),'브랜드미상'))
                gid=make_id('PRODUCT-RULE-',group);mode='제품_동일표기_브랜드기준_잠정';flags=[]
            else:
                group=(typ,nid);gid=make_id('PRODUCT-LOCAL-',nid);mode='제품_개별보존_검토필요';flags=[]
                if not literal:flags.append('제품명_원문표기재확인')
                if not context:flags.append('대상기업_문맥재확인')
                if len(brands)>1:flags.append('브랜드_복수후보')
        else:
            # 정확한 발생 연도가 있다면 같은 명칭이라도 다른 연도는 묶지 않는다.
            years={str(r.get('attributes',{}).get('event_date'))[:4] for r,_ in items
                   if re.fullmatch(r'\d{4}-\d{2}-\d{2}',str(r.get('attributes',{}).get('event_date') or ''))}
            if literal and context and len(years)<=1:
                group=(typ,key(name),next(iter(years),'연도미상'))
                gid=make_id('EVENT-RULE-',group);mode='행사_동일표기_연도구분_잠정';flags=[]
            else:
                group=(typ,nid);gid=make_id('EVENT-LOCAL-',nid);mode='행사_개별보존_검토필요';flags=[]
                if not literal:flags.append('행사명_원문표기재확인')
                if not context:flags.append('대상기업_문맥재확인')
                if len(years)>1:flags.append('행사연도_충돌')
        if gid not in new_nodes:
            new_nodes[gid]={'entity_id':gid,'type':typ,'name':name,'identity_status':mode,
                            'old_ids':[],'source_names':[],'attribute_variants':[], 'review_flags':[]}
        dest=new_nodes[gid]
        if dest['type']!=typ:raise ValueError('서로 다른 개체 유형이 같은 ID에 연결됨')
        dest['old_ids'].append(nid)
        if name not in dest['source_names']:dest['source_names'].append(name)
        if old_attrs not in dest['attribute_variants']:dest['attribute_variants'].append(old_attrs)
        dest['review_flags']=sorted(set(dest['review_flags']+flags))
        resolution[nid]=gid
        if typ!='MetricObservation' and mode.endswith('_잠정'):groups[group]=gid
        map_rows.append({'old_entity_id':nid,'new_entity_id':gid,'original_name':name,'type':typ,
            'source_mention':src,'original_attributes':old_attrs,'identity_status':mode,
            'name_in_source':literal,'target_company_in_source':context,'review_flags':flags,
            'related_relation_ids':[r['relation_id'] for r,_ in items]})

    # 이번 대상 15,022건은 원문과 속성을 그대로 두고 미결 측 개체 ID만 교체한다.
    added=[]
    for r,side,nid,node in selected:
        out=dict(r)
        out['original_subject_id']=r['subject_id'];out['original_object_id']=r['object_id']
        out['original_subject_resolution']=r['subject_resolution'];out['original_object_resolution']=r['object_resolution']
        out[side+'_id']=resolution[nid];out[side+'_resolution']=new_nodes[resolution[nid]]['identity_status']
        out['review_status']='규칙기반연결_관계의미검토필요';out['scope']='기존_한쪽미결_'+node['type']
        added.append(out)

    # 이전 2,676건에서 같은 이름의 Event만 같은 그룹에 연결한다.
    # 기존 사람 매핑과 제외 범위, 제품·브랜드 간 관계는 그대로 보존한다.
    updated_prior=[];prior_event_changes=0
    for r in prior_relations:
        out=dict(r);changed=False;chunk=chunks.get(r['evidence']['chunk_id'],{});text=chunk.get('primary_text','')
        for side in ('subject','object'):
            nid=r[side+'_id'];n=old_by_id.get(nid)
            if not n or n['type']!='Event':continue
            name=n['name'];date=r.get('attributes',{}).get('event_date')
            year=date[:4] if isinstance(date,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',date) else '연도미상'
            group=('Event',key(name),year)
            if group in groups and key(name) and key(name) in key(text) and any(c in text for c in COMPANIES):
                out['before_event_'+side+'_id']=nid
                out[side+'_id']=groups[group];out[side+'_resolution']='행사_동일표기_연도구분_잠정';changed=True
        if changed:
            out['review_status']='행사_규칙기반잠정_관계검토필요';prior_event_changes+=1
        updated_prior.append(out)
    scope=updated_prior+added
    ids=[r['relation_id'] for r in scope]
    if len(ids)!=len(set(ids)) or set(ids)&both:raise ValueError('관계 중복 또는 양쪽 미결 제외 범위 침범')
    for r in scope:
        x=original[r['relation_id']]
        if any(r[k]!=x[k] for k in ('predicate','attributes','evidence','source_kind')):
            raise ValueError(f'원문이나 속성 변경: {r["relation_id"]}')

    # 실제 범위 관계에 필요한 노드와 구조화 기준 노드를 함께 모은다.
    pool={**old_by_id,**person_by_id,**new_nodes}
    if len(pool)!=len(old_by_id)+len(person_by_id)+len(new_nodes):raise ValueError('새 개체 ID 충돌')
    needed={r[k] for r in scope+structured for k in ('subject_id','object_id')}
    needed.update(n['entity_id'] for n in old_nodes if n['entity_id'].startswith(('COMPANY-','FINANCIAL-')))
    if needed-set(pool):raise ValueError('관계 끝점 개체 누락: '+str(next(iter(needed-set(pool)))))
    scope_nodes=[pool[i] for i in sorted(needed)]
    # 원래 2,539건과 기타 33건은 ID 목록으로만 보존한다.
    if len(both)+len(other)+len(scope)!=len(relations):raise ValueError('전체 관계 범위 합계 불일치')
    a.output.mkdir(parents=True,exist_ok=True)
    save(a.output/'nodes_in_scope.jsonl',scope_nodes)
    save(a.output/'new_nonperson_nodes.jsonl',new_nodes.values())
    save(a.output/'nonperson_mention_mappings.jsonl',map_rows)
    save(a.output/'person_mention_mappings.jsonl',person_mappings)
    save(a.output/'previous_person_mappings.jsonl',previous_person_mappings)
    save(a.output/'news_relations_in_scope.jsonl',scope)
    save(a.output/'structured_disclosure_relations.jsonl',structured)
    save(a.output/'disclosure_documents.jsonl',disc_docs)
    save(a.output/'disclosure_chunks.jsonl',disc_chunks)
    save(a.output/'excluded_both_unresolved.jsonl',({'relation_id':x,'reason':'처리 전 양쪽 모두 미결'} for x in sorted(both)))
    save(a.output/'excluded_other_one_sided.jsonl',({'relation_id':r['relation_id'],'reason':'이번에 제외한 기타 개체 유형'} for r in other))
    status=Counter(n['identity_status'] for n in new_nodes.values())
    categories=Counter(node['type'] for _,_,_,node in selected)
    distinct=Counter(node['type'] for nid,node in ((nid,old_by_id[nid]) for nid in per_id))
    result={'input_sha256':{'m4':h4,'m5':h5,'person':sha(a.person)},
        'original_news_relations':len(relations),'previous_person_scope':len(prior_relations),
        'additional_relations_by_type':dict(categories),'additional_relations':len(selected),
        'additional_distinct_mentions_by_type':dict(distinct),'new_nodes_by_status':dict(status),
        'previous_scope_event_relations_remapped':prior_event_changes,
        'in_scope_news_relations':len(scope),'in_scope_nodes':len(scope_nodes),
        'structured_and_disclosure_relations':len(structured),'metric_shared_multiple_targets_nodes':len(shared_metric),
        'metric_shared_multiple_targets_relations':sum(len(per_id[nid]) for nid in shared_metric),
        'excluded_both_unresolved':len(both),'excluded_other_types':len(other),
        'status':'규칙기반 잠정 연결 또는 개별 보존. 원문 의미·실제 사실 검증 필요',
        'verification':'뉴스 전체 범위 분할, 관계 ID 중복·누락, 양끝 개체 존재, 원문·서술어·속성 보존 확인'}
    (a.output/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
