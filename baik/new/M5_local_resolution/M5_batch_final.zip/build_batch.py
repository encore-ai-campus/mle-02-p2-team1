#!/usr/bin/env python3
"""M5 일괄 잠정 정규화. 검증된 M5 ZIP에서 생성하며 API를 호출하지 않는다."""
import argparse,collections,hashlib,json,re,unicodedata,zipfile
from pathlib import Path

def norm(s): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',s)).strip().casefold()
def hid(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
def lines(z,n):
 for l in z.open(n):
  if l.strip():yield json.loads(l)
def write(p, rows):
 with p.open('w',encoding='utf8',newline='\n') as f:
  for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')

def main():
 a=argparse.ArgumentParser();a.add_argument('--input',type=Path,required=True);a.add_argument('--output',type=Path,required=True);x=a.parse_args();
 if x.output.exists():raise ValueError('기존 출력 폴더 사용 불가')
 x.output.mkdir(parents=True)
 with zipfile.ZipFile(x.input) as z:
  ms=list(lines(z,'results/mentions_mapping.jsonl'));rs=list(lines(z,'results/news_relations.jsonl'));ses=list(lines(z,'results/structured_entities.jsonl'));srs=list(lines(z,'results/structured_relations.jsonl'))
 if len(ms)!=29245 or len(rs)!=20270: raise ValueError('원본 행수 불일치: 기대하는 스냅샷 확인')
 global_types={'Company','Brand','Place','Market','Organization','CorporateGroup','Character'};local_types={'Person','Event','Product'}
 groups=collections.defaultdict(list)
 for m in ms:
  e=m['original_entity']; typ=e['type']; name=norm(e['name']); attrs=e.get('attributes',{})
  if not name:continue
  if typ in global_types:key=('global',typ,name)
  elif typ in local_types:key=('document',m['document_id'],typ,name,json.dumps(attrs,ensure_ascii=False,sort_keys=True))
  else:continue
  groups[key].append(m)
 stat=collections.Counter(); conflicts=[]
 for key,items in groups.items():
  fixed={m['output_entity_id'] for m in items if m.get('output_status')=='잠정_검토필요'}
  # 문서 내 임시 ID는 최종 승인 ID가 아니다. 단 같은 이름에 기존 대표 ID가 둘이면 보류한다.
  hard={v for v in fixed if not v.startswith(('PROV-DOC-','PENDING-SAMEDOC-','UNRESOLVED-'))}
  if key[0]=='document':hard=fixed
  if len(hard)>1:
   conflicts.append({'group':key,'existing_ids':sorted(fixed),'mentions':len(items),'reason':'기존 대표 ID 충돌: 자동 병합 보류'});continue
  if len(items)<2:continue
  target=next(iter(hard)) if hard else 'AUTO-'+hid(key)
  for m in items:
   if m['output_entity_id']==target:continue
   m['previous_output_entity_id']=m['output_entity_id'];m['previous_output_status']=m['output_status']
   m['output_entity_id']=target;m['output_status']='자동연결_미검토';m['batch_rule']='동일유형_정규화표기' if key[0]=='global' else '동일문서_유형_표기_속성';stat[m['batch_rule']]+=1
 # 동일 청크의 후보 ID는 유일해야 관계 양끝을 안전하게 연결할 수 있다.
 lookup={}
 for m in ms:
  k=(m['chunk_id'],m['candidate_entity_id'])
  if k in lookup: raise ValueError('모호한 같은 청크 후보 ID')
  lookup[k]=m
 for r in rs:
  for side in ('subject','object'):
   key=(r['chunk_id'],r['source_candidate_'+side+'_id'])
   if key not in lookup:raise ValueError('관계 끝점 언급 누락')
   m=lookup[key];r[side+'_id']=m['output_entity_id'];r[side+'_resolution']=m['output_status']
 # 동일 끝점/유형/속성 관계만 결합. 주장 원본은 별도 보존.
 grouped={}
 for r in rs:
  key=[r['subject_id'],r['predicate'],r['object_id'],r['attributes']]; encoded=json.dumps(key,ensure_ascii=False,sort_keys=True); g=grouped.setdefault(encoded,{'relation_id':'REL-'+hid(key),'subject_id':key[0],'predicate':key[1],'object_id':key[2],'attributes':key[3],'source_assertions':[],'review_status':'검토필요'})
  g['source_assertions'].append({'assertion_id':r['assertion_id'],'document_id':r['document_id'],'chunk_id':r['chunk_id'],'evidence':r['evidence'],'source_metadata':r['source_metadata'],'review_status':r.get('review_status')})
 entities=collections.defaultdict(list)
 for m in ms:entities[m['output_entity_id']].append(m)
 entityout=[]
 for id,items in entities.items():
  e=items[0]['original_entity']; variants={json.dumps(t['original_entity'].get('attributes',{}),ensure_ascii=False,sort_keys=True) for t in items}; entityout.append({'entity_id':id,'type':e['type'],'name':e['name'],'attributes':e.get('attributes',{}),'attribute_variants':[json.loads(v) for v in sorted(variants)],'attribute_conflict':len(variants)>1,'mention_count':len(items),'review_status':'검토필요','structured_id':id if id.startswith('COMPANY-') else None})
 summary={'news_mentions':len(ms),'structured_entities':len(ses),'structured_relations':len(srs),'news_assertions':len(rs),'grouped_news_relations':len(grouped),'news_entity_ids':len(entityout),'new_automatic_mentions':dict(stat),'statuses':dict(collections.Counter(m['output_status'] for m in ms)),'conflicting_groups':len(conflicts),'input_sha256':hashlib.sha256(x.input.read_bytes()).hexdigest(),'warning':'자동 연결은 미검증 추론: 특히 동일명 기업·브랜드·장소 오병합 가능; 지표는 통합하지 않음'}
 write(x.output/'mentions_mapping.jsonl',ms);write(x.output/'news_assertions.jsonl',rs);write(x.output/'news_relations_grouped.jsonl',grouped.values());write(x.output/'news_entities.jsonl',entityout);write(x.output/'conflicts_review.jsonl',conflicts);write(x.output/'structured_entities.jsonl',ses);write(x.output/'structured_relations.jsonl',srs)
 (x.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
 assert sum(len(g['source_assertions']) for g in grouped.values())==len(rs)
 print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
