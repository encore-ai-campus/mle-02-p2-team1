# M5 일괄 처리 결과 — 자동 연결 미검토

M4 성공 4,757청크에 대한 M5_company_brand_phase.zip을 입력으로 일괄 처리한 결과다. API 추가 호출이나 DB 접근은 없다. 미처리 2,108청크와 실패 13청크는 포함되지 않는다.

## 결과와 해석
- 뉴스 언급 29,245건을 모두 처리: 기존 잠정 751건, 이번 자동연결·미검토 10,108건, 미결 18,386건.
- 뉴스 개체 ID 18,763개(미결 임시 ID 포함). 원자료의 구조화 기업 ID와 겹치므로 구조화 21개와 단순 합산 금지. 확정 고유 개체 수가 아니다.
- 뉴스 관계 20,270건을 동일 주어/관계/목적어/관계속성 기준 18,604개 그룹으로 묶고 출처별 주장 20,270개 모두 보존. 근거 문자열·속성은 사실 검증되지 않았다.
- 구조화 개체 21개·관계 14개 별도 보존. 출처와 금융 원문 검토 필요.

## 일괄 기준
Company/Brand/Place/Market/Organization/CorporateGroup/Character는 유형과 NFKC·공백·대소문자 정규화 이름이 같으면 전역 잠정 연결한다. 구별된 대표 ID가 충돌하면 보류하고, 브랜드와 법인은 유형을 분리한다. 문서 단위 PROV-DOC/PENDING 기존 ID는 대표 ID로 간주하지 않으며 과거 ID와 상태를 유지한다. Person/Event/Product는 같은 문서·유형·이름·추출 속성이 일치할 때에만 묶고, 기존 대표 ID 충돌 시 보류한다. MetricObservation은 같은 이름이라는 이유만으로 묶지 않는다. 미결 언급은 개별 임시 ID를 유지한다.

주의: 동일 이름/유형이라도 다른 회사·브랜드·지역을 가리키거나 LLM이 타입을 잘못 판단했을 수 있다. 자동연결은 정확성 보증이 아니며 기사 표본과 예외를 확인해야 한다. 원문 근거가 청크에 있다는 기존 검사는 의미·사실성을 보장하지 않는다. 같은 기사 재전재는 독립 근거가 아닐 수 있다. 이 결과를 최종 승인 그래프에 무검토 적재하지 않는다. 사전 검토 또는 검토필요 표시가 있는 분리된 시험 그래프에서만 사용 여부를 결정한다.

## 파일
- `results/mentions_mapping.jsonl`: 원래 표기·문서·청크 및 이전/현재 ID와 상태.
- `results/news_entities.jsonl`: 뉴스 개체 ID별 이름·유형·속성 및 서로 다른 속성 목록, 불일치 표시. MetricObservation 수치도 보존한다. 이 파일과 `structured_entities`에서 같은 ID는 하나의 개체로 명시적 병합해야 한다.
- `results/news_assertions.jsonl`: 20,270건 출처별 주장의 업데이트된 양끝·근거·메타데이터.
- `results/news_relations_grouped.jsonl`: 같은 의미 속성의 관계 그룹과 개별 출처 목록. 시점·수치·상태가 다른 관계는 별도다.
- `results/structured_entities.jsonl`, `structured_relations.jsonl`: 입력 구조화 기록 유지.
- `results/conflicts_review.jsonl`: 확정된 기존 대표 ID의 충돌 후보.
- `results/summary.json`: 입력 해시·전후 수량·상태.

## 재현
Python 3.10+, 표준 라이브러리. 입력은 제공된 `M5_company_brand_phase.zip`; 결과 폴더는 존재하지 않아야 한다.

```powershell
uv run .\build_batch.py --input .\M5_company_brand_phase.zip --output .\m5_batch_output
```

입력 ZIP과 원문은 포함하지 않는다. SHA-256은 요약에 기록하지만 코드가 예상값을 강제하지 않으므로 같은 스냅샷인지 대조해야 한다. 전체 업로드 전 개인정보·기사 이용 조건 검토 필요. 실제 Neo4j 실행, 재적재 및 동일성 정확도 검증은 하지 않았다.
