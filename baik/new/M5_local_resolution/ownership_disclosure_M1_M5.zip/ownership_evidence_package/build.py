from pathlib import Path
from lxml import html
import json, csv, re, hashlib

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
SOURCES = [
    {'id':'APH-2025-ANNUAL','file':'holdings_2025_annual.html','as_of':'2025-12-31','filed':'2026-03-18','url':'https://kind.krx.co.kr/external/2026/03/18/001082/20260318005107/11011.htm'},
    {'id':'APH-2026-Q1','file':'holdings_2026_q1.html','as_of':'2026-03-31','filed':'2026-05-15','url':'https://kind.krx.co.kr/external/2026/05/15/001430/20260515003119/11013.htm'},
]
COMPANIES = {
    '아모레퍼시픽홀딩스': ('COMPANY-AMOREPACIFIC-HOLDINGS','주식회사 아모레퍼시픽홀딩스'),
    '아모레퍼시픽': ('COMPANY-AMOREPACIFIC','주식회사 아모레퍼시픽'),
    '이니스프리': ('COMPANY-INNISFREE','주식회사 이니스프리'),
    '에스쁘아': ('COMPANY-ESPOIR','주식회사 에스쁘아'),
    '에뛰드': ('COMPANY-ETUDE','주식회사 에뛰드'),
    '퍼시픽테크': ('COMPANY-PACIFICTECH','주식회사 퍼시픽테크'),
    '아모스프로페셔널': ('COMPANY-AMOSPROFESSIONAL','주식회사 아모스프로페셔널'),
    '코스알엑스': ('COMPANY-COSRX','주식회사 코스알엑스'),
}
def compact(element):
    return ' '.join(element.text_content().split())
def identify(text):
    text = re.sub(r'\(\*\d+\)', '', text).strip().replace('㈜','').replace('(주)','').strip()
    return text if text in COMPANIES else None
def save_jsonl(name, rows):
    with (OUT / name).open('w', encoding='utf-8', newline='\n') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')

entities = [{'entity_id': value[0], 'name': value[1], 'type':'Company', 'identity_status': '기존_대표ID' if key != '아모레퍼시픽홀딩스' else '신규_제안ID_기존홀딩스와_대조필요'} for key,value in COMPANIES.items()]
chunks, relations, manifests = [], [], []
for source in SOURCES:
    path = ROOT / 'sources' / source['file']
    tree = html.parse(str(path))
    selected = []
    for table in tree.xpath('//table'):
        trs=table.xpath('.//tr')
        rows = [[compact(c) for c in tr.xpath('./th|./td')] for tr in trs]
        if rows and '투자회사' in rows[0] and '피투자회사' in rows[0] and any('퍼시픽테크' in ' '.join(row) and '100.0' in row for row in rows):
            selected.append((table,trs,rows))
    if not selected:
        raise RuntimeError(f'종속기업 표를 찾지 못함: {path}')
    table, trs, rows = selected[0]
    table_xpath = tree.getpath(table)
    data_count = 0
    for i, row in enumerate(rows[1:],1):
        if len(row) < 6: continue
        parent, child = identify(row[0]), identify(row[1])
        if parent not in ('아모레퍼시픽홀딩스','아모레퍼시픽') or child not in COMPANIES or child == '아모레퍼시픽홀딩스': continue
        n=float(row[3]); assert 0 <= n <= 100
        row_path = tree.getpath(trs[i]); chunk_id=source['id']+'-'+COMPANIES[child][0]
        # 표의 결산일은 피투자회사의 결산일이며 소유 기준일이 아니다.
        text=' | '.join(row)
        chunk={'document_id':source['id'],'chunk_id':chunk_id,'as_of_date':source['as_of'], 'section':'연결재무제표 주석 1.2 종속기업의 현황','header':rows[0], 'text':text,'source_xpath':row_path,'source_url':source['url']}
        chunks.append(chunk)
        qualifier='보고서 기재 지분율; 주식 종류 및 분모 별도 확인'
        if child=='아모레퍼시픽': qualifier='연결 종속기업 표의 지분율 38.1%; 의결권 50% 미만에도 사실상 지배 주석. 별도 보통주 주주현황 38.0%와 표·분모 구분'
        if child=='이니스프리': qualifier='보고서 별도재무제표 지분율 주석: 이니스프리 자기주식을 제외한 실질지분율; 명목 지분율로 단정 금지'
        relations.append({'relation_id':'OWN-'+source['as_of']+'-'+COMPANIES[child][0], 'subject_id':COMPANIES[parent][0], 'subject_name':COMPANIES[parent][1], 'predicate':'OWNS_STAKE','object_id':COMPANIES[child][0], 'object_name':COMPANIES[child][1], 'value_number':n,'unit':'%', 'as_of_date':source['as_of'], 'percentage_basis':qualifier, 'source_document_id':source['id'], 'chunk_id':chunk_id,'evidence_quote':text,'review_status':'공시표_대조완료_적재전_스키마검토필요','scope':'표의 투자회사별 지분율; 간접 지분 추정 아님'})
        data_count += 1
    assert data_count==7,(source['id'],data_count)
    # 38.1%에 붙은 주석을 원문에서 추출하여 별도 보존한다.
    notes=[compact(e) for e in tree.xpath('//p') if '지배기업이 보유한 의결권 있는 지분율은 50% 미만' in compact(e)]
    assert notes
    notes2=[compact(e) for e in tree.xpath('//p') if '이니스프리가 보유하고 있는 자기주식을 제외한 실질지분율' in compact(e)]
    assert notes2
    for kind,txt in [('control',notes[0]),('innisfree_basis',notes2[0])]:
        chunks.append({'document_id':source['id'],'chunk_id':source['id']+'-NOTE-'+kind,'as_of_date':source['as_of'],'section':'종속기업 지분율 주석','text':txt,'source_url':source['url']})
    manifests.append({**source,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'table_xpath':table_xpath,'target_rows':data_count})

# 기존 M5의 별도 회사 노드는 같은 법인인지 검토할 후보로만 기록한다.
aliases=[('이니스프리','AUTO-3d295451c1408042c9ad79cb'),('에스쁘아','AUTO-7785385cb280f1df432367ec'),('에뛰드','AUTO-48ad7b9e61f64a1c361248a0'),('퍼시픽테크','AUTO-7f4fedbbd22e3c9296148c89'),('아모스프로페셔널','AUTO-043dbec8e837fb94f889d3eb'),('아모레퍼시픽홀딩스','AUTO-35e7396534ca88cbf4b974da')]
crosswalk=[{'original_entity_id':old,'original_name':name,'candidate_entity_id':COMPANIES[name][0],'entity_type':'Company','decision':'동일법인_검토후_병합','reason':'명칭 후보; 기존 원문 문맥과 법인 식별자 확인 필요. 브랜드 개체는 병합하지 않음'} for name,old in aliases]
save_jsonl('documents.jsonl', manifests)
save_jsonl('chunks.jsonl', chunks)
save_jsonl('entities.jsonl', entities)
save_jsonl('relations.jsonl', relations)
save_jsonl('identity_crosswalk_review.jsonl', crosswalk)
with (OUT/'relations.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(relations[0]));w.writeheader();w.writerows(relations)
assert len(relations)==14 and len(entities)==8
assert len({r['relation_id'] for r in relations})==14
print(f'문서 {len(manifests)}, 근거 청크 {len(chunks)}, 회사 {len(entities)}, 관계 {len(relations)}, 매핑 검토 {len(crosswalk)}')
